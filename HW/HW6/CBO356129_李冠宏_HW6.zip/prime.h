#ifndef PRIME_H
#define PRIME_H

int IsPrime(int num);

#endif